package org.test.tommy;

import javax.swing.tree.TreeNode;
import java.io.*;
import java.util.*;

public class Solution {
    static class Part {
        public String getName() { return "X"; }
    }

    public static class Operation {
        private String name_;
        public Operation(final String name) { name_ = name; }
        public String getName() { return name_; }
        public String operate(Part p) {
            return "Operation " + name_ + " on part " + p.getName();
        }
    }

    public static class StepManager {


        Tree<Operation> t = null;

        public void addOperation(final Operation operation, final String[] prerequisites) {

            if(t == null){

            }

        }
        public void performOperation(String operationName, Part p) {
            // Add your implementation here. When this method is called,
            // you must call the 'operate()' method for the named operation,
            // as well as all prerequisites for that operation.
        }
    }

    public static void main(String[] args) throws Exception {
        StepManager manager = new StepManager();

        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        String s;
        while ((s = in.readLine()) != null && s.length() != 0) {
            if (s.startsWith("#")) {
                continue;
            }
            String[] parts = s.split(",");
            manager.addOperation(new Operation(parts[0]),  Arrays.copyOfRange(parts, 1, parts.length));
        }

        manager.performOperation("final", new Part());
    }



    public class Tree<T> {
        private Node<T> root;

        public Tree(T rootData) {
            root = new Node<T>();
            root.data = rootData;
            root.children = new ArrayList<Node<T>>();
        }
    }

    public class Node<T> {
        private T data;
        private Node<T> parent;
        private List<Node<T>> children;
    }
}


