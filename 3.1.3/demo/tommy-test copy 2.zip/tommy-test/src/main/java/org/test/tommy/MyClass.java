package org.test.tommy;


public class MyClass {



}
